"""公开服务端的采样权限与耗时短检；Smoke-test sampler permissions and cost on the public server."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/mnt/c/Users/92110/Desktop/Linger/ling')
sys.path.insert(0, str(ROOT / 'benchmarks'))
import v030

OUTPUT = Path('/root/ling-acceptance/rss-smoke-20261118-0535')
OUTPUT.mkdir(exist_ok=False)
PORT = v030.free_port()
CONFIG = OUTPUT / 'ling.toml'
CONFIG.write_text(f'[server]\nhost="127.0.0.1"\nport={PORT}\n[log]\nlevel="error"\n')
binary = Path('/root/ling-acceptance/v020-public-441ffc7/ling/ling')
samples = []
observer = None
with (OUTPUT / 'server.log').open('wb') as log:
    server = subprocess.Popen([str(binary), '--config', str(CONFIG)], cwd=OUTPUT, stdout=log, stderr=log)
    try:
        deadline = time.monotonic() + 15
        while observer is None:
            try:
                observer = v030.Client(PORT)
            except OSError:
                if server.poll() is not None or time.monotonic() >= deadline:
                    raise RuntimeError('public server did not start')
                time.sleep(.02)
        for number in range(32):
            before = time.monotonic()
            snapshot = v030.native_snapshot(server.pid)
            duration = time.monotonic() - before
            assert snapshot['rss_source'] == 'proc_smaps_rollup:Rss'
            assert all(type(snapshot[field]) in (int, float) and snapshot[field] >= 0
                       for field in ('rss_bytes', 'cpu_seconds', 'handles', 'threads', 'vmrss_approximate_bytes'))
            samples.append({'number': number, 'duration_seconds': duration, 'native': snapshot})
            time.sleep(.02)
        reply = observer.request('SHUTDOWN')
        server.wait(timeout=10)
        assert server.returncode == 0
    finally:
        if observer is not None:
            observer.close()
        if server.poll() is None:
            server.terminate()
            server.wait(timeout=10)
        result = {'samples': samples, 'server_exit_code': server.returncode,
                  'scope': '32 native RSS reads; not load calibration or endurance',
                  'max_native_sample_seconds': max((row['duration_seconds'] for row in samples), default=None),
                  'sampler_sha256': v030.sha256(ROOT / 'benchmarks/v030.py'),
                  'binary_sha256': v030.sha256(binary), 'python': sys.version,
                  'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
        (OUTPUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
