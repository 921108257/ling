#!/usr/bin/env python3
"""真实0.2制品的隔离存储故障验收；Isolated storage acceptance for a verified 0.2 release.

Defaults to a plan. --execute requires the dedicated ling-acceptance WSL, root,
an exact binary SHA-256/revision, and a new /var/tmp/ling-acceptance-storage-* root.
Never operates on an existing Journal, installation, service, or block device.
The ENOSPC child uses its own mount namespace and a bounded 64 MiB ext4 image.
This is software/virtual-filesystem fault evidence, not physical power-loss proof.
"""
import argparse
from collections import deque
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import struct
import subprocess
import sys
import time
import uuid
import zlib

sys.dont_write_bytecode = True
HEADER = struct.Struct(">2sBBHQI")
MAX_REPLY = 2 * 1024 * 1024
IMAGE_BYTES = 64 * 1024 * 1024
MIN_FREE = 10 * 1024 * 1024 * 1024
MARKER = Path("/root/ling-acceptance/.wsl-crash-acceptance")
RUN_MARKER = "ling-storage-acceptance-v1\n"
PLAN = [
    "seed: two databases/two shards, durable named groups, ACK hole, offline full-directory backup",
    "restore: same topology/stream/ACK hole, empty cache, continued sequence; wrong topology/second owner rejected",
    "readonly: baseline access then chmod(0400) Journal under an unprivileged numeric UID; startup rejected",
    "quota: 1 MiB Journal, atomic ERR_JOURNAL_FULL, bounded pending, persistent ACK reserve, larger-budget clone",
    "runtime-read: append a short tail / corrupt an event CRC; preserve bytes and reject later durable operations",
    "startup: repair only recognizable incomplete tails; ambiguous payload truncation and bad middle CRC rejected",
    "enospc: private mount namespace + 64 MiB loop ext4, bounded filler, real kernel ENOSPC, unknown write retained",
]


def serial(value):
    """字节保持精确；Preserve binary identities without text coercion."""
    if isinstance(value, bytes):
        return {"bytes_hex": value.hex()}
    if isinstance(value, dict):
        return {str(key): serial(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, deque)):
        return [serial(item) for item in value]
    return value


def save(path, value):
    """只写本轮目录；Write only this run's evidence."""
    Path(path).write_text(json.dumps(serial(value), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(path):
    """流式文件摘要；Stream a file digest."""
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def require(condition, message):
    """失败保留现场；Fail without silently weakening acceptance."""
    if not condition:
        raise RuntimeError(message)


class Evidence:
    """完整顺序记录意图、成功与未知；Ordered records separate intent, success and unknown outcomes."""
    def __init__(self, directory):
        self.directory = Path(directory)
        self.output = (self.directory / "actions.jsonl").open("a", encoding="utf-8", buffering=1)

    def add(self, action, **details):
        """记录后立即刷新；Flush each evidence record."""
        self.output.write(json.dumps(serial({"action": action, "monotonic_ns": time.monotonic_ns(),
                                           "utc": datetime.now(timezone.utc).isoformat(), **details}),
                                     ensure_ascii=False) + "\n")
        self.output.flush()

    def close(self):
        """控制记录与故障文件系统分离；Control evidence is outside the failing filesystem."""
        self.output.flush()
        os.fsync(self.output.fileno())
        self.output.close()


class WireError(RuntimeError):
    """稳定服务端错误与本地协议错误；Stable server and local protocol errors."""


def encode(value):
    """仅编码所需严格类型；Encode the strict types used by this acceptance."""
    if value is None:
        return b"\0"
    if isinstance(value, bool):
        return b"\1" + bytes([value])
    if isinstance(value, int):
        return b"\3" + struct.pack(">Q", value)
    if isinstance(value, (str, bytes)):
        data = value.encode("utf-8") if isinstance(value, str) else value
        return bytes([5 if isinstance(value, str) else 6]) + struct.pack(">I", len(data)) + data
    if isinstance(value, list):
        return b"\7" + struct.pack(">I", len(value)) + b"".join(map(encode, value))
    if isinstance(value, dict):
        return b"\10" + struct.pack(">I", len(value)) + b"".join(encode(k) + encode(v) for k, v in value.items())
    raise WireError("LOCAL_ENCODING: unsupported type")


def decode(data, offset=0, depth=0):
    """长度与深度先验；Validate lengths and nesting before decoding."""
    require(depth <= 16 and offset < len(data), "LOCAL_PROTOCOL: truncated/nested Value")
    tag, offset = data[offset], offset + 1
    if tag == 0:
        return None, offset
    if tag == 1:
        require(offset < len(data) and data[offset] <= 1, "LOCAL_PROTOCOL: Bool")
        return bool(data[offset]), offset + 1
    if tag in (2, 3, 4):
        require(offset + 8 <= len(data), "LOCAL_PROTOCOL: number")
        return struct.unpack_from({2: ">q", 3: ">Q", 4: ">d"}[tag], data, offset)[0], offset + 8
    require(tag in (5, 6, 7, 8, 9) and offset + 4 <= len(data), "LOCAL_PROTOCOL: tag")
    count = struct.unpack_from(">I", data, offset)[0]
    offset += 4
    require(count <= len(data) - offset, "LOCAL_PROTOCOL: container length")
    if tag in (5, 6):
        raw = data[offset:offset + count]
        return (raw.decode("utf-8") if tag == 5 else raw), offset + count
    result = {} if tag == 8 else []
    for _ in range(count):
        key, offset = decode(data, offset, depth + 1)
        if tag == 8:
            require(isinstance(key, str) and key and key not in result, "LOCAL_PROTOCOL: Map key")
            result[key], offset = decode(data, offset, depth + 1)
        else:
            result.append(key)
    return result, offset


class Client:
    """绝对请求期限、有界事件缓存、从不重放；Absolute deadlines, bounded inbox and no replay."""
    def __init__(self, port):
        self.stream = socket.create_connection(("127.0.0.1", port), timeout=2)
        self.stream.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.identity, self.events = 0, deque()
        try:
            self.hello = self.request("HELLO", [1])
            require(self.hello.get("reliable_events") is True, "Reliable HELLO required")
        except BaseException:
            self.close()
            raise

    def read(self, size, until):
        """每次读取使用同一期限；Every fragmented read uses the same deadline."""
        result = bytearray()
        while len(result) < size:
            left = until - time.monotonic()
            if left <= 0:
                raise TimeoutError("absolute frame deadline")
            self.stream.settimeout(left)
            part = self.stream.recv(size - len(result))
            if not part:
                raise WireError("LOCAL_EOF: incomplete frame")
            result.extend(part)
        return bytes(result)

    def frame(self, until):
        """校验线上封套与完整Value；Validate the wire envelope and complete Value."""
        magic, version, kind, flags, identity, size = HEADER.unpack(self.read(HEADER.size, until))
        require(magic == b"LG" and version == 1 and flags == 0 and size <= MAX_REPLY,
                "LOCAL_PROTOCOL: frame header")
        payload = self.read(size, until)
        if kind == 5:
            require(identity == 0 and not payload, "LOCAL_PROTOCOL: heartbeat")
            return kind, identity, None
        require(kind in (2, 3, 6), "LOCAL_PROTOCOL: frame kind")
        offset = 1 if kind == 2 else 0
        require(kind != 2 or payload[:1] in (b"\0", b"\1"), "LOCAL_PROTOCOL: status")
        value, offset = decode(payload, offset)
        if kind == 6 or (kind == 2 and payload[0] == 1):
            detail, offset = decode(payload, offset)
            require(isinstance(value, str) and isinstance(detail, str) and offset == len(payload),
                    "LOCAL_PROTOCOL: error fields")
            raise WireError(value + ": " + detail)
        require(offset == len(payload), "LOCAL_PROTOCOL: trailing Value")
        require(time.monotonic() < until, "LOCAL_TIMEOUT: late complete frame")
        return kind, identity, value

    def request(self, command, arguments=(), kind=1):
        """一连接串行，ID只匹配响应；Serial requests use IDs only for response matching."""
        self.identity += 1
        payload = encode(arguments) if kind == 4 else encode(command) + encode(list(arguments))
        require(len(payload) <= MAX_REPLY, "LOCAL_LIMIT: request")
        until = time.monotonic() + 2
        self.stream.settimeout(2)
        self.stream.sendall(HEADER.pack(b"LG", 1, kind, 0, self.identity, len(payload)) + payload)
        while True:
            frame_kind, identity, value = self.frame(until)
            if frame_kind == 5:
                continue
            if frame_kind == 3:
                require(identity == 0 and len(self.events) < 32, "LOCAL_LIMIT: event inbox")
                self.events.append(value)
                continue
            require(frame_kind == 2 and identity == self.identity, "LOCAL_PROTOCOL: response ID")
            return value

    def event(self, seconds=3):
        """重投观察有有限期限；Bound observation of delivery/redelivery."""
        if self.events:
            return self.events.popleft()
        until = time.monotonic() + seconds
        while True:
            kind, identity, value = self.frame(until)
            if kind == 5:
                continue
            require(kind == 3 and identity == 0, "LOCAL_PROTOCOL: subscription frame")
            return value

    def close(self):
        """只关闭自有连接；Close only this client's socket."""
        self.stream.close()


def listener_owned(pid, port):
    """连接前匹配自有PID的监听inode；Match the child PID's listener inode before connecting."""
    try:
        inodes = set()
        for item in Path(f"/proc/{pid}/fd").iterdir():
            try:
                link = os.readlink(item)
                if link.startswith("socket:["):
                    inodes.add(link[8:-1])
            except OSError:
                continue
        for line in Path(f"/proc/{pid}/net/tcp").read_text().splitlines()[1:]:
            fields = line.split()
            if len(fields) >= 10 and fields[1] == f"0100007F:{port:04X}" and fields[3] == "0A" and fields[9] in inodes:
                return True
    except OSError:
        pass
    return False


def configuration(port, journal, limit=16 * 1024 * 1024, dbs=2, shards=2, retry=100, pending=4):
    """无业务TTL，显式拓扑与全部相关预算；No TTL workload, with explicit topology and budgets."""
    return f'''[server]
host="127.0.0.1"
port={port}
max_connections=16
idle_timeout_ms=600000
request_timeout_ms=2000
shutdown_timeout_ms=3000
max_request_bytes=2097152
max_response_bytes=2097152
[database]
databases={dbs}
[engine]
shard_count={shards}
max_memory_bytes=8388608
[eviction]
policy="noeviction"
[events]
mode="reliable"
retention_days=7
buffer_bytes=4194304
max_pending_events={pending}
max_groups=8
consumer_timeout_ms={retry}
retry_interval_ms={retry}
notification_enabled=true
[event_journal]
dir={json.dumps(str(journal))}
max_bytes={limit}
[log]
level="info"
[metrics]
enabled=false
'''


class Server:
    """只启动与回收本轮登记子进程；Launch and reap only a registered child."""
    def __init__(self, binary, directory, evidence, journal=None, uid=None, **config):
        self.directory, self.evidence, self.clients = Path(directory), evidence, []
        self.directory.mkdir(parents=True, exist_ok=True)
        self.directory.chmod(0o755)
        self.stopped = False
        self.journal = Path(journal) if journal else self.directory / "journal"
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            self.port = probe.getsockname()[1]
        self.config = self.directory / "server.toml"
        self.config.write_text(configuration(self.port, self.journal, **config), encoding="utf-8")
        self.config.chmod(0o644)
        self.log = (self.directory / "server.log").open("ab")
        command = [str(binary), "--config", str(self.config)]
        if uid is not None:
            command = ["setpriv", f"--reuid={uid}", f"--regid={uid}", "--clear-groups", *command]
        try:
            self.process = subprocess.Popen(command, cwd=self.directory, stdin=subprocess.DEVNULL,
                                            stdout=self.log, stderr=self.log)
            evidence.add("server_started", pid=self.process.pid, command=command, config_sha256=sha(self.config))
        except BaseException:
            if hasattr(self, "process") and self.process.poll() is None:
                self.process.kill()
                self.process.wait(timeout=5)
            self.log.close()
            raise

    def ready(self):
        """不得把其他监听者当成自己的服务；Never use an unrelated listener as readiness."""
        until = time.monotonic() + 8
        while time.monotonic() < until:
            require(self.process.poll() is None, "server exited before readiness; inspect server.log")
            if listener_owned(self.process.pid, self.port):
                try:
                    client = Client(self.port)
                    if self.process.poll() is not None or not listener_owned(self.process.pid, self.port):
                        client.close()
                        raise RuntimeError("child listener disappeared during handshake")
                    self.clients.append(client)
                    return client
                except OSError:
                    pass
            time.sleep(.02)
        raise TimeoutError("owned server readiness deadline")

    def client(self, db=0):
        """连接前后都核验归属；Check listener ownership before and after each connection."""
        require(self.process.poll() is None and listener_owned(self.process.pid, self.port), "owned listener missing")
        client = Client(self.port)
        self.clients.append(client)
        require(self.process.poll() is None and listener_owned(self.process.pid, self.port), "listener changed")
        if db:
            require(client.request("SELECT", [db]) is True, "SELECT failed")
        return client

    def reject(self, code):
        """失败启动不应监听，日志须有稳定错误码；Rejected startup must not listen and must report its stable code."""
        status = self.process.wait(timeout=8)
        self.log.flush()
        text = (self.directory / "server.log").read_text(encoding="utf-8", errors="replace")
        require(status != 0 and code in text, f"startup did not reject with {code}: {text}")
        require(not listener_owned(self.process.pid, self.port), "rejected server still listens")
        self.evidence.add("startup_rejected", pid=self.process.pid, exit_code=status, code=code)

    def stop(self, graceful=False):
        """停止只作用于Popen持有的PID；Stop only the process held by Popen."""
        if self.stopped:
            return
        try:
            if self.process.poll() is None and graceful:
                client = self.client()
                result = call(self.evidence, client, "SHUTDOWN")
                require(result["ok"], "graceful SHUTDOWN failed")
                require(self.process.wait(timeout=5) == 0, "graceful server exit was nonzero")
            elif self.process.poll() is None:
                self.process.kill()
                self.process.wait(timeout=5)
        finally:
            if self.process.poll() is None:
                self.process.kill()
                self.process.wait(timeout=5)
            for client in self.clients:
                client.close()
            self.log.close()
            self.stopped = True
            self.evidence.add("server_stopped", pid=self.process.pid, exit_code=self.process.returncode,
                              graceful_requested=graceful)


@contextmanager
def running(binary, directory, evidence, **options):
    """异常也回收子进程；Reap the child on every failure path."""
    server = Server(binary, directory, evidence, **options)
    try:
        yield server
    finally:
        server.stop()


def call(evidence, client, command, arguments=(), kind=1):
    """不重放；已发送写入异常明确保留未知状态；Never replay and retain unknown write outcomes."""
    evidence.add("request_intent", command=command, arguments=arguments, kind=kind)
    try:
        value = client.request(command, arguments, kind)
        result = {"ok": True, "value": value}
    except (OSError, RuntimeError, ValueError) as error:
        code = str(error).split(":", 1)[0]
        known = isinstance(error, WireError) and code.startswith("ERR_") and code != "ERR_COMMIT_UNKNOWN"
        result = {"ok": False, "error": repr(error), "error_type": type(error).__name__, "code": code,
                  "write_result_may_be_unknown": command in ("SET", "MSET", "ACK", "SUBSCRIBE") and not known}
    evidence.add("request_result", command=command, **result)
    return result


def ok(evidence, client, command, arguments=(), kind=1):
    """成功必须有完整响应；Require a complete success response."""
    result = call(evidence, client, command, arguments, kind)
    require(result["ok"], f"unexpected {command} failure: {result}")
    return result["value"]


def fails(evidence, client, command, arguments, code, kind=1):
    """核对明确错误，不把EOF伪装为服务端拒绝；Check the exact error without disguising EOF as rejection."""
    result = call(evidence, client, command, arguments, kind)
    require(not result["ok"] and result["code"] == code, f"expected {code}: {result}")
    return result


def journal_scan(path):
    """只读物理校验，不修复或替代服务端语义校验；Read-only physical validation, never repair."""
    require(Path(path).stat().st_size <= 128 * 1024 * 1024, "Journal inspection budget")
    data = Path(path).read_bytes()
    require(len(data) >= 40 and data[:12] == b"LGJRNL01\0\0\0\1" and zlib.crc32(data[:36]) == int.from_bytes(data[36:40], "big"),
            "invalid Journal header")
    result = {"bytes": len(data), "sha256": sha(path), "stream_id": data[12:28].hex(),
              "databases": int.from_bytes(data[28:32], "big"), "shards": int.from_bytes(data[32:36], "big"),
              "records": [], "events": [], "status": "complete"}
    offset = 40
    while offset < len(data):
        if len(data) - offset < 8:
            result.update(status="short_header", offset=offset)
            break
        size, checksum = struct.unpack_from(">II", data, offset)
        require(size <= 2 * 1024 * 1024, "Journal record inspection budget")
        end = offset + 8 + size
        if end > len(data):
            result.update(status="ambiguous_payload", offset=offset)
            break
        payload = data[offset + 8:end]
        if zlib.crc32(payload) != checksum:
            result.update(status="bad_crc", offset=offset)
            break
        trailer = data[end:end + 8]
        if trailer != b"LGCMT001":
            result.update(status="short_trailer" if b"LGCMT001".startswith(trailer) else "bad_trailer", offset=offset)
            break
        require(payload and payload[0] in (1, 2, 3), "unknown Journal record tag")
        result["records"].append({"offset": offset, "bytes": size + 16, "tag": payload[0]})
        if payload[0] == 1:
            count, at = int.from_bytes(payload[1:5], "big"), 5
            require(0 < count <= len(payload), "invalid event count")
            for _ in range(count):
                require(at + 19 <= len(payload), "truncated event fields")
                db, shard, sequence, event_kind, length = struct.unpack_from(">HIQBI", payload, at)
                at += 19
                require(at + length + 40 <= len(payload), "truncated event body")
                key = payload[at:at + length].decode("utf-8")
                at += length
                epoch = payload[at:at + 16].hex()
                generation, revision, timestamp = struct.unpack_from(">QQQ", payload, at + 16)
                at += 40
                result["events"].append({"db": db, "shard": shard, "sequence": sequence,
                                         "kind": event_kind, "key": key, "epoch": epoch,
                                         "generation": generation, "revision": revision, "timestamp_ms": timestamp})
            require(at == len(payload), "trailing Journal event bytes")
        offset = end + 8
    return result


def archive(journal, destination):
    """保存完整目录字节并记录源所有权；Preserve full directory bytes and record original ownership separately."""
    journal, destination = Path(journal), Path(destination)
    require(journal.is_dir() and not journal.is_symlink(), "unexpected Journal directory")
    manifest = {}
    source_paths = sorted(journal.rglob("*"))
    for path in source_paths:
        require(not path.is_symlink() and (path.is_dir() or path.is_file()), "unexpected Journal entry")
        if path.is_file():
            stat = path.stat()
            manifest[str(path.relative_to(journal))] = {"bytes": stat.st_size, "sha256": sha(path),
                "source_mode": oct(stat.st_mode & 0o777), "source_uid": stat.st_uid, "source_gid": stat.st_gid}
    require("journal.lgj" in manifest, "Journal file missing from archive")
    shutil.copytree(journal, destination)
    require([path.relative_to(journal) for path in source_paths] ==
            [path.relative_to(journal) for path in sorted(journal.rglob("*"))], "Journal directory changed during archive")
    for name, entry in manifest.items():
        original, copied = journal / name, destination / name
        require(sha(original) == entry["sha256"] == sha(copied), "Journal bytes changed during archive")
        stat = copied.stat()
        entry["copy_mode"], entry["copy_uid"], entry["copy_gid"] = oct(stat.st_mode & 0o777), stat.st_uid, stat.st_gid
    save(destination.with_suffix(".manifest.json"), {"files": manifest,
         "ownership_policy": "Source uid/gid recorded; copytree copies byte contents and modes, not ownership"})
    return manifest


def identity(event):
    """完整事件ID作为比较单位；Compare the complete event identity."""
    value = event["event_id"]
    return (value["stream_id"].hex(), value["db"], value["shard"], value["sequence"])


def seed(binary, directory, evidence):
    """留一个真实ACK空洞；Create an actual durable ACK hole before sealing a backup."""
    with running(binary, directory, evidence, retry=600000) as server:
        writer = server.ready()
        sub = server.client()
        ok(evidence, sub, "SUBSCRIBE", [["*"], "GROUP", "storage-seed"])
        all_events = []
        for number in range(4):
            ok(evidence, writer, "SET", ["seed-key", number + 1])
            event = sub.event()
            evidence.add("event", event=event)
            all_events.append(event)
        # 同Key保证同分片，第二条ACK不能越过第一条；Same key fixes the shard, preserving a real hole.
        ok(evidence, sub, "ACK", all_events[1]["event_id"], kind=4)
        other = server.client(db=1)
        ok(evidence, other, "SET", ["db1-marker", 7])
        metadata = ok(evidence, writer, "INFO", ["all"])
        save(Path(directory) / "before-stop-info.json", metadata)
        result = {"stream_id": writer.hello["stream_id"].hex(), "events": all_events,
                  "acked": identity(all_events[1]), "replay": [identity(event) for index, event in enumerate(all_events) if index != 1]}
        server.stop(graceful=True)
    archive(Path(directory) / "journal", Path(directory) / "sealed-journal")
    save(Path(directory) / "journal-scan.json", journal_scan(Path(directory) / "sealed-journal/journal.lgj"))
    save(Path(directory) / "seed.json", result)
    return result


def restore_case(binary, directory, evidence, source, baseline):
    """离线副本恢复、拓扑与目录锁；Offline clone recovery, topology and directory-lock checks."""
    journal = Path(directory) / "journal"
    shutil.copytree(source, journal)
    with running(binary, directory, evidence, retry=600000) as server:
        writer = server.ready()
        require(writer.hello["stream_id"].hex() == baseline["stream_id"], "stream changed on restore")
        require(ok(evidence, writer, "DBSIZE") == 0, "cache restored unexpectedly")
        require(ok(evidence, server.client(db=1), "DBSIZE") == 0, "db1 cache restored unexpectedly")
        sub = server.client()
        ok(evidence, sub, "SUBSCRIBE", [["*"], "GROUP", "storage-seed"])
        expected = set(tuple(item) for item in baseline["replay"])
        for _ in range(len(expected)):
            event = sub.event()
            value = identity(event)
            require(value in expected, "unexpected/duplicate/ACKed replay")
            expected.remove(value)
            evidence.add("replayed_event", event=event)
            ok(evidence, sub, "ACK", event["event_id"], kind=4)
        require(not expected, "missing committed replay")
        ok(evidence, writer, "SET", ["seed-key", 9])
        continued = sub.event()
        current = continued["event_id"]
        tail = max((event["event_id"]["sequence"] for event in baseline["events"]
                    if event["event_id"]["db"] == current["db"] and event["event_id"]["shard"] == current["shard"]), default=0)
        require(identity(continued)[0] == baseline["stream_id"] and current["sequence"] == tail + 1,
                "logical stream sequence did not continue")
        evidence.add("continued_event", event=continued)
        with running(binary, Path(directory) / "second-owner", evidence, journal=journal) as rejected:
            rejected.reject("ERR_JOURNAL_UNAVAILABLE")
        server.stop(graceful=True)
    archive(journal, Path(directory) / "after-journal")
    wrong = Path(directory) / "wrong-topology"
    wrong.mkdir()
    shutil.copytree(source, wrong / "journal")
    before = sha(wrong / "journal/journal.lgj")
    with running(binary, wrong, evidence, shards=1) as rejected:
        rejected.reject("ERR_CONFIG_INVALID")
    require(sha(wrong / "journal/journal.lgj") == before, "wrong topology mutated Journal")
    archive(wrong / "journal", wrong / "rejected-journal")


def readonly_case(binary, directory, evidence, source):
    """非root真实权限拒绝，不能用root条件跳过；Real unprivileged denial, without a root bypass."""
    import pwd
    uid = 60003
    try:
        pwd.getpwuid(uid)
    except KeyError:
        pass
    else:
        raise RuntimeError("reserved test UID 60003 already has an account")
    directory = Path(directory)
    directory.mkdir()
    journal = directory / "journal"
    shutil.copytree(source, journal)
    for path in [directory, *directory.rglob("*")]:
        os.chown(path, uid, uid)
    # 先证明同身份可运行该副本；First prove the same UID can access and run this clone.
    with running(binary, directory / "baseline", evidence, journal=journal, uid=uid) as server:
        server.ready()
        server.stop(graceful=True)
    target = journal / "journal.lgj"
    target.chmod(0o400)
    frozen = sha(target)
    probe = subprocess.run(["setpriv", f"--reuid={uid}", f"--regid={uid}", "--clear-groups",
                            sys.executable, "-c", "import sys; open(sys.argv[1], 'r+b')", str(target)],
                           capture_output=True, text=True, timeout=5)
    evidence.add("readonly_permission_probe", uid=uid, exit_code=probe.returncode, stderr=probe.stderr)
    require(probe.returncode != 0 and "PermissionError" in probe.stderr, "read-only permissions were not enforced")
    with running(binary, directory / "denied", evidence, journal=journal, uid=uid) as rejected:
        rejected.reject("ERR_JOURNAL_UNAVAILABLE")
    require(sha(target) == frozen, "read-only rejection mutated Journal")
    archive(journal, directory / "denied-journal")
    target.chmod(0o600)
    with running(binary, directory / "restored-permission", evidence, journal=journal, uid=uid) as server:
        server.ready()
        server.stop(graceful=True)
    archive(journal, directory / "restored-journal")


def quota_case(binary, directory, evidence):
    """逻辑容量拒绝不等于I/O故障；Distinguish logical capacity rejection from I/O faults."""
    directory = Path(directory)
    key, last = "quota:" + "x" * 990, 0
    with running(binary, directory, evidence, limit=1048576, dbs=1, shards=1, retry=600000) as server:
        writer = server.ready()
        sub = server.client()
        ok(evidence, sub, "SUBSCRIBE", [["*"], "GROUP", "quota"])
        until = time.monotonic() + 120
        for number in range(1, 1001):
            require(time.monotonic() < until, "quota phase deadline")
            result = call(evidence, writer, "SET", [key, number])
            if not result["ok"]:
                require(result["code"] == "ERR_JOURNAL_FULL" and not result["write_result_may_be_unknown"],
                        "quota did not produce a definite precommit refusal")
                break
            last = number
        else:
            raise RuntimeError("1 MiB Journal did not exhaust within 1000 bounded writes")
        require(last > 0 and ok(evidence, writer, "GET", [key]) == last, "quota rejection changed the last value")
        event = sub.event()
        ok(evidence, sub, "ACK", event["event_id"], kind=4)
        info = ok(evidence, writer, "INFO", ["events"])["events"]
        require(info["pending"] <= 4 and info["journal_bytes"] <= 524288, "quota/ACK reserve budget violated")
        require(info["journal_errors"] == 0, "logical quota incorrectly counted as I/O fault")
        evidence.add("quota_confirmed", last_success=last, events=info)
        server.stop(graceful=True)
    archive(directory / "journal", directory / "full-journal")
    bigger = directory / "larger-budget"
    bigger.mkdir()
    shutil.copytree(directory / "full-journal", bigger / "journal")
    before = journal_scan(bigger / "journal/journal.lgj")
    with running(binary, bigger, evidence, limit=2097152, dbs=1, shards=1) as server:
        client = server.ready()
        require(client.hello["stream_id"].hex() == before["stream_id"], "budget change changed stream")
        require(ok(evidence, client, "DBSIZE") == 0, "capacity restart restored cache")
        ok(evidence, client, "SET", [key, last + 1])
        server.stop(graceful=True)
    archive(bigger / "journal", bigger / "after-journal")


def mutate(path, mode):
    """只变更本轮副本，返回首个受影响偏移；Mutate only an owned clone and return its first affected offset."""
    scan = journal_scan(path)
    data = bytearray(Path(path).read_bytes())
    if mode == "short-header":
        offset = len(data)
        data.extend(b"\0\0")
    elif mode == "short-trailer":
        offset = len(data)
        last = scan["records"][-1]
        data.extend(data[last["offset"]:last["offset"] + last["bytes"] - 4])
    elif mode == "ambiguous-payload":
        last = scan["records"][-1]
        offset = last["offset"]
        data = data[:offset + 9]
    elif mode == "middle-crc":
        offset = next(record["offset"] for record in scan["records"] if record["tag"] == 1)
        data[offset + 8] ^= 1
        data.extend(b"\0\0")
    else:
        raise RuntimeError("unknown mutation")
    with Path(path).open("r+b") as output:
        output.write(data)
        output.truncate()
        output.flush()
        os.fsync(output.fileno())
    return offset, len(data), sha(path)


def independent_subcases(evidence, suite, modes, operation):
    """独立场景失败后继续并记录，不修改产品；Record independent failures and continue without product fixes."""
    failures = []
    for mode in modes:
        try:
            operation(mode)
            evidence.add("subcase_completed", suite=suite, case=mode, passed=True)
        except Exception as error:
            failures.append({"case": mode, "error": repr(error)})
            evidence.add("subcase_completed", suite=suite, case=mode, passed=False, error=repr(error))
    require(not failures, f"{suite} subcases failed: {failures}")


def startup_cases(binary, directory, evidence, source):
    """确认短尾才可修，其他损坏逐字节保留；Repair only proven tails and preserve all other corruption."""
    def run_mode(mode):
        case = Path(directory) / mode
        case.mkdir(parents=True)
        shutil.copytree(source, case / "journal")
        path = case / "journal/journal.lgj"
        original = path.read_bytes()
        offset, size, digest = mutate(path, mode)
        evidence.add("mutation", case=mode, offset=offset, bytes=size, sha256=digest)
        archive(case / "journal", case / "injected-journal")
        with running(binary, case, evidence) as server:
            if mode.startswith("short-"):
                client = server.ready()
                require(ok(evidence, client, "DBSIZE") == 0, "tail recovery restored cache")
                require(path.read_bytes() == original, "tail repair did not preserve the complete prefix")
                server.stop(graceful=True)
            else:
                server.reject("ERR_JOURNAL_UNAVAILABLE")
                require(sha(path) == digest and path.stat().st_size == size, "rejected corruption was modified")
                log = (case / "server.log").read_text(encoding="utf-8", errors="replace")
                require(f"byte offset {offset}" in log, "corruption offset missing from startup diagnostic")
        archive(case / "journal", case / "after-journal")
    independent_subcases(evidence, "startup_recovery",
                         ("short-header", "short-trailer", "ambiguous-payload", "middle-crc"), run_mode)


def runtime_cases(binary, directory, evidence):
    """运行期遍历只读、全局故障与空闲订阅唤醒；Read-only runtime traversal and global fault notification."""
    def run_mode(mode):
        case = Path(directory) / mode
        with running(binary, case, evidence, retry=200) as server:
            writer = server.ready()
            active, idle = server.client(), server.client()
            ok(evidence, active, "SUBSCRIBE", [["*"], "GROUP", "active"])
            ok(evidence, idle, "SUBSCRIBE", [["*"], "GROUP", "idle"])
            ok(evidence, writer, "SET", ["runtime-probe", 1])
            first, idle_first = active.event(), idle.event()
            require(identity(first) == identity(idle_first), "group delivery identities differed")
            ok(evidence, idle, "ACK", idle_first["event_id"], kind=4)
            if mode == "short-header":
                ok(evidence, active, "ACK", first["event_id"], kind=4)
            ok(evidence, active, "UNSUBSCRIBE")
            # 仅idle仍订阅；先观察扫描计数静止，不能把先前ACK通知当成故障唤醒。
            # With only idle subscribed, observe quiescence before injecting, excluding outstanding ACK notifications.
            until, quiet_since, previous = time.monotonic() + 3, None, None
            while True:
                stats = ok(evidence, writer, "INFO", ["events"])["events"]
                now, polls = time.monotonic(), stats["subscription_polls"]
                require(stats["pending"] == (0 if mode == "short-header" else 1), "unexpected idle/pending setup")
                if polls != previous:
                    previous, quiet_since = polls, now
                elif now - quiet_since >= .25:
                    break
                require(now < until, "idle subscription did not quiesce before injection")
                time.sleep(.025)
            evidence.add("idle_subscription_quiescent", case=mode, quiet_seconds=now - quiet_since, events=stats)
            path = case / "journal/journal.lgj"
            archive(case / "journal", case / "pre-injection-journal")
            offset, size, digest = mutate(path, mode)
            evidence.add("runtime_mutation", case=mode, offset=offset, bytes=size, sha256=digest)
            # 已有组重订阅不追加：短尾触发续读；CRC触发断线租约重投的从头读取。
            # Existing-group resubscription appends nothing: read the tail or redeliver the disconnected pending event.
            ok(evidence, active, "SUBSCRIBE", [["*"], "GROUP", "active"])
            outcomes = []
            for client in (active, idle):
                until, delivered = time.monotonic() + 3, []
                for _ in range(32):
                    try:
                        delivered.append(client.event(seconds=max(.001, until - time.monotonic())))
                    except (OSError, RuntimeError) as error:
                        outcomes.append({"error": str(error), "queued_redeliveries": delivered})
                        break
                    require(time.monotonic() < until, "runtime fault notification deadline")
                else:
                    raise RuntimeError("runtime fault observer exceeded bounded redelivery count")
            evidence.add("fault_subscription_outcomes", case=mode, outcomes=outcomes)
            require(all(item["error"].startswith("ERR_JOURNAL_UNAVAILABLE:") for item in outcomes),
                    "runtime fault did not reach both active and idle subscriptions")
            require(any(f"byte offset {offset}" in item["error"] for item in outcomes),
                    "runtime first-fault offset missing")
            fails(evidence, writer, "SET", ["after-read-fault", 2], "ERR_JOURNAL_UNAVAILABLE")
            require(sha(path) == digest and path.stat().st_size == size, "runtime read fault rewrote Journal")
            save(case / "fault-info.json", ok(evidence, writer, "INFO", ["events"]))
        archive(case / "journal", case / "faulted-journal")
    independent_subcases(evidence, "runtime_read", ("short-header", "middle-crc"), run_mode)


def probe(command, evidence, **options):
    """有界外部工具，仅保存真实退出结果；Bound external tools and record their actual results."""
    result = subprocess.run(command, capture_output=True, text=True, timeout=30, **options)
    evidence.add("command", command=command, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr)
    require(result.returncode == 0, f"command failed: {command}: {result.stderr}")
    return result


@contextmanager
def failed_io_trace(server, directory, evidence):
    """仅记录失败系统调用以确认实际ENOSPC；Trace failed syscalls to confirm the actual ENOSPC errno."""
    path = Path(directory) / "failed-io.strace"
    with (Path(directory) / "strace.log").open("wb") as log:
        command = ["strace", "-f", "-qq", "-s", "32", "-e", "trace=write,writev,pwrite64,fsync,fdatasync",
                   "-e", "status=failed", "-o", str(path), "-p", str(server.process.pid)]
        tracer = subprocess.Popen(command, stdout=log, stderr=log)
        try:
            until = time.monotonic() + 3
            while True:
                require(tracer.poll() is None, "strace exited before attaching; no ENOSPC fault started")
                status = Path(f"/proc/{server.process.pid}/status").read_text()
                attached = re.search(r"^TracerPid:\s+(\d+)", status, flags=re.MULTILINE)
                if attached and int(attached.group(1)) == tracer.pid:
                    break
                require(time.monotonic() < until, "strace attach deadline; no ENOSPC fault started")
                time.sleep(.02)
            evidence.add("io_trace_attached", tracer_pid=tracer.pid, server_pid=server.process.pid, command=command)
            yield path
        finally:
            if tracer.poll() is None:
                tracer.terminate()
                try:
                    tracer.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    tracer.kill()
                    tracer.wait(timeout=3)
            evidence.add("io_trace_stopped", tracer_pid=tracer.pid, exit_code=tracer.returncode)


def enospc_worker(args):
    """只在独立挂载命名空间创建文件系统；Create the filesystem only in a private mount namespace."""
    root = Path(args.output).resolve(strict=True)
    require(root.parent == Path("/var/tmp") and re.fullmatch(r"ling-acceptance-storage-[0-9a-f]{32}", root.name), "unexpected worker root")
    require(sys.platform == "linux" and os.geteuid() == 0 and os.environ.get("WSL_DISTRO_NAME") == "ling-acceptance",
            "worker requires dedicated WSL root")
    require(MARKER.read_text() == "ling-acceptance\n", "dedicated WSL marker missing")
    require((root / ".storage-acceptance").read_text() == RUN_MARKER, "owned run marker missing")
    require(os.readlink("/proc/self/ns/mnt") != args.parent_namespace, "private mount namespace was not created")
    require(Path(args.binary).resolve(strict=True) == root / "inputs/ling", "worker binary must be the frozen input")
    require(sha(args.binary) == json.loads((root / "environment.json").read_text())["binary_sha256"], "worker binary changed")
    evidence = Evidence(root)
    directory = root / "enospc"
    directory.mkdir()
    image, mountpoint = directory / "disk.ext4", directory / "mount"
    mountpoint.mkdir()
    mounted = False
    try:
        with image.open("xb") as output:
            os.posix_fallocate(output.fileno(), 0, IMAGE_BYTES)
            os.fsync(output.fileno())
        probe(["mkfs.ext4", "-q", "-F", "-m", "0", "-E", "lazy_itable_init=0,lazy_journal_init=0", str(image)], evidence)
        probe(["mount", "-o", "loop,nodev,nosuid", str(image), str(mountpoint)], evidence)
        mounted = True
        evidence.add("private_mount", mount_namespace=os.readlink("/proc/self/ns/mnt"), image_bytes=image.stat().st_size,
                     findmnt=probe(["findmnt", "-T", str(mountpoint)], evidence).stdout)
        with running(Path(args.binary), directory / "server", evidence, journal=mountpoint / "journal",
                     limit=268435456, dbs=1, shards=1, retry=600000, pending=1) as server:
            writer = server.ready()
            sub = server.client()
            ok(evidence, sub, "SUBSCRIBE", [["*"], "GROUP", "disk"])
            key = "disk:" + "x" * 990
            ok(evidence, writer, "SET", [key, 1])
            pending = sub.event()
            # 满交付窗口令订阅停止追加控制记录，故障应由明确的SET触发。
            # A full delivery window prevents background group writes from racing the deliberate SET failure.
            archive(mountpoint / "journal", directory / "pre-fault-journal")
            # 填充只发生在64MiB镜像内；Filler allocation is confined to the 64 MiB image.
            with failed_io_trace(server, directory, evidence) as trace_path:
                with (mountpoint / "filler").open("xb") as filler:
                    allocated = 0
                    for _ in range(128):
                        stats = os.statvfs(mountpoint)
                        available = stats.f_bavail * stats.f_frsize
                        if available <= 65536:
                            break
                        chunk = min(1048576, available - 65536)
                        os.posix_fallocate(filler.fileno(), allocated, chunk)
                        allocated += chunk
                    else:
                        raise RuntimeError("bounded filler did not approach the small filesystem limit")
                    os.fsync(filler.fileno())
                evidence.add("disk_filled", filler_bytes=allocated,
                             available_bytes=os.statvfs(mountpoint).f_bavail * os.statvfs(mountpoint).f_frsize)
                last, unknown = 1, None
                until = time.monotonic() + 120
                for number in range(2, 5002):
                    require(time.monotonic() < until, "ENOSPC application phase deadline")
                    result = call(evidence, writer, "SET", [key, number])
                    if not result["ok"]:
                        require(result["code"] == "ERR_COMMIT_UNKNOWN" and result["write_result_may_be_unknown"],
                                "physical disk exhaustion did not retain unknown commit status")
                        unknown = number
                        break
                    last = number
                require(unknown is not None, "small filesystem did not cause an application I/O failure")
                fails(evidence, writer, "SET", ["after-disk-fault", 1], "ERR_JOURNAL_UNAVAILABLE")
                # 先记录订阅的明确故障ERROR；其后TCP关闭可能阻止单独ACK响应，不能把EOF冒称稳定错误。
                # Observe the explicit subscription fault first; a subsequent TCP close is not an ACK error response.
                try:
                    unexpected = sub.event(seconds=3)
                except (OSError, RuntimeError) as error:
                    require(isinstance(error, WireError) and str(error).startswith("ERR_JOURNAL_UNAVAILABLE:"),
                            "subscription closed without an explicit Journal fault; ACK boundary unconfirmed")
                    evidence.add("subscription_fault_before_ack", code="ERR_JOURNAL_UNAVAILABLE", error=str(error))
                else:
                    raise RuntimeError(f"faulted subscription delivered unexpected event: {serial(unexpected)}")
                ack = call(evidence, sub, "ACK", pending["event_id"], kind=4)
                require(not ack["ok"], "ACK unexpectedly succeeded after the global Journal fault")
                stable_ack_code = ack["code"] == "ERR_JOURNAL_UNAVAILABLE"
                require(stable_ack_code or ack["code"] == "LOCAL_EOF" or
                        ack["error_type"] in ("BrokenPipeError", "ConnectionResetError", "ConnectionAbortedError"),
                        "unexpected post-fault ACK result")
                evidence.add("post_fault_ack_observation", result=ack, stable_error_response_observed=stable_ack_code,
                             boundary="explicit Journal fault already observed; closed connection leaves ACK unconfirmed")
                require(ok(evidence, writer, "GET", [key]) == last, "failed I/O published the candidate value")
                info = ok(evidence, writer, "INFO", ["events"])
                save(directory / "fault-info.json", info)
                save(directory / "outcomes.json", {"last_confirmed": last, "unknown": unknown,
                    "unknown_request_replayed": False, "ack_result": ack, "stable_ack_error_response_observed": stable_ack_code,
                    "ack_boundary": "A fatal subscription ERROR can close TCP before a separate ACK response; transport close is reported separately",
                    "scope": "bounded loop ext4 ENOSPC; no forced fsync EIO"})
            require(re.search(r"= -1 ENOSPC\b", trace_path.read_text()), "the kernel trace did not confirm ENOSPC")
        archive(mountpoint / "journal", directory / "faulted-journal")
        save(directory / "faulted-journal-scan.json", journal_scan(directory / "faulted-journal/journal.lgj"))
        # 只在新副本尝试恢复，模糊短尾允许明确拒绝；Only attempt recovery on a fresh clone; ambiguous tails may reject.
        recovered = directory / "recovery"
        recovered.mkdir()
        shutil.copytree(directory / "faulted-journal", recovered / "journal")
        before = sha(recovered / "journal/journal.lgj")
        with running(Path(args.binary), recovered, evidence, limit=268435456, dbs=1, shards=1) as server:
            try:
                client = server.ready()
            except RuntimeError:
                server.reject("ERR_JOURNAL_UNAVAILABLE")
                require(sha(recovered / "journal/journal.lgj") == before, "rejected unknown tail was modified")
                evidence.add("disk_recovery", result="explicitly_rejected_ambiguous_tail", unknown=unknown)
            else:
                require(ok(evidence, client, "DBSIZE") == 0, "disk recovery restored cache")
                scan = journal_scan(recovered / "journal/journal.lgj")
                sequences = [event["sequence"] for event in scan["events"]]
                require(sequences == list(range(1, last + 1)) or sequences == list(range(1, unknown + 1)),
                        "recovery lost confirmed events or invented extra commits")
                evidence.add("disk_recovery", result="recovered", last_confirmed=last, unknown=unknown,
                             unknown_survived=unknown in sequences)
                server.stop(graceful=True)
        archive(recovered / "journal", recovered / "after-journal")
        return 0
    finally:
        body_failed, cleanup_errors = sys.exc_info()[0] is not None, []
        try:
            if mounted:
                try:
                    if (mountpoint / "journal").is_dir() and not (directory / "faulted-journal").exists():
                        archive(mountpoint / "journal", directory / "faulted-journal-on-failure")
                except Exception as error:
                    cleanup_errors.append({"phase": "failure_archive", "error": repr(error)})
                finally:
                    try:
                        result = subprocess.run(["umount", str(mountpoint)], capture_output=True, text=True, timeout=10)
                        evidence.add("unmount", exit_code=result.returncode, stderr=result.stderr)
                        require(result.returncode == 0, "private unmount failed; namespace exit will release mount")
                    except Exception as error:
                        cleanup_errors.append({"phase": "unmount", "error": repr(error)})
            try:
                if image.exists():
                    evidence.add("image_preserved", path=str(image), bytes=image.stat().st_size, sha256=sha(image))
            except Exception as error:
                cleanup_errors.append({"phase": "image_digest", "error": repr(error)})
            if cleanup_errors:
                evidence.add("cleanup_failed", errors=cleanup_errors)
            if not body_failed:
                require(not cleanup_errors, "ENOSPC cleanup failed; inspect retained evidence")
        finally:
            evidence.close()


def execute(args):
    """全部故障仅作用于新建目录；All faults target a newly created, owned test directory."""
    require(sys.platform == "linux" and os.geteuid() == 0, "run inside the dedicated WSL as root")
    require(os.environ.get("WSL_DISTRO_NAME") == "ling-acceptance", "only ling-acceptance WSL is authorized")
    require(MARKER.is_file() and MARKER.read_text() == "ling-acceptance\n", "dedicated WSL marker missing")
    root = Path(args.output).resolve()
    require(root.parent == Path("/var/tmp") and re.fullmatch(r"ling-acceptance-storage-[0-9a-f]{32}", root.name),
            "output must be a new /var/tmp/ling-acceptance-storage-<32 hex UUID> directory")
    require(not root.exists(), "refuse to reuse an existing output directory")
    require(shutil.disk_usage("/var/tmp").free >= MIN_FREE and shutil.disk_usage("/mnt/c").free >= MIN_FREE,
            "both WSL and Windows host require at least 10 GiB free")
    for command in ("setpriv", "unshare", "mkfs.ext4", "mount", "umount", "findmnt", "strace"):
        require(shutil.which(command) is not None, "required command unavailable: " + command)
    binary = Path(args.binary).resolve(strict=True)
    require(re.fullmatch(r"[0-9a-f]{64}", args.binary_sha256 or "") and sha(binary) == args.binary_sha256,
            "verified binary SHA-256 mismatch")
    require(re.fullmatch(r"[0-9a-f]{40}", args.revision or ""), "exact 40-digit release revision required")
    root.mkdir(mode=0o755)
    root.chmod(0o755)
    (root / ".storage-acceptance").write_text(RUN_MARKER)
    frozen = root / "inputs"
    frozen.mkdir()
    frozen.chmod(0o755)
    target = frozen / "ling"
    shutil.copyfile(binary, target)
    target.chmod(0o755)
    require(sha(target) == args.binary_sha256, "binary changed while freezing")
    shutil.copyfile(Path(__file__).resolve(), frozen / "storage_acceptance.py")
    version = subprocess.run([str(target), "--version"], capture_output=True, text=True, timeout=5)
    require(version.returncode == 0 and re.search(r"\b0\.2\.0\b", version.stdout), "requires the real 0.2.0 release binary")
    save(root / "environment.json", {"created_utc": datetime.now(timezone.utc).isoformat(), "binary": str(binary),
        "binary_sha256": sha(target), "release_revision_operator_verified": args.revision, "version": version.stdout,
        "script_sha256": sha(frozen / "storage_acceptance.py"), "distro": os.environ.get("WSL_DISTRO_NAME"),
        "uid": os.getuid(), "kernel": os.uname(), "python": sys.version,
        "free_wsl": shutil.disk_usage("/var/tmp").free, "free_host": shutil.disk_usage("/mnt/c").free,
        "limitations": ["No physical power loss", "No device write-cache assurance", "No injected fsync EIO",
                        "No production online backup/cross-host migration guarantee", "No product changes"]})
    save(root / "plan.json", PLAN)
    evidence = Evidence(root)
    results = []
    try:
        baseline = seed(target, root / "seed", evidence)
        source = root / "seed/sealed-journal"
        for name, operation in (
            ("restore_topology_and_lock", lambda: restore_case(target, root / "restore", evidence, source, baseline)),
            ("readonly", lambda: readonly_case(target, root / "readonly", evidence, source)),
            ("quota", lambda: quota_case(target, root / "quota", evidence)),
            ("runtime_read", lambda: runtime_cases(target, root / "runtime", evidence)),
            ("startup_recovery", lambda: startup_cases(target, root / "startup", evidence, source)),
        ):
            try:
                operation()
                results.append({"case": name, "passed": True})
            except Exception as error:
                evidence.add("case_failed", case=name, error=repr(error))
                results.append({"case": name, "passed": False, "error": repr(error)})
            save(root / "progress.json", results)
        # 私有进程组只含此worker及其子服务；The private process group contains only this worker and its services.
        command = ["unshare", "--mount", "--propagation", "private", sys.executable, "-B", str(frozen / "storage_acceptance.py"),
                   "--enospc-worker", "--output", str(root), "--binary", str(target),
                   "--parent-namespace", os.readlink("/proc/self/ns/mnt")]
        with (root / "enospc-worker.log").open("wb") as output:
            worker = subprocess.Popen(command, stdout=output, stderr=output, start_new_session=True)
            try:
                status = worker.wait(timeout=180)
                results.append({"case": "enospc", "passed": status == 0, "worker_exit": status})
            except subprocess.TimeoutExpired as error:
                os.killpg(worker.pid, signal.SIGKILL)
                worker.wait(timeout=5)
                results.append({"case": "enospc", "passed": False, "error": repr(error)})
            except BaseException:
                if worker.poll() is None:
                    os.killpg(worker.pid, signal.SIGKILL)
                    worker.wait(timeout=5)
                raise
        passed = len(results) == 6 and all(result["passed"] for result in results)
        save(root / "summary.json", {"passed": passed, "results": results, "seed": baseline,
             "scope": "verified 0.2.0 release; isolated WSL filesystem/software faults; not physical power-loss proof",
             "evidence_policy": "All original and injected Journals retained; failures recorded, no product fixes"})
        return 0 if passed else 1
    except BaseException as error:
        evidence.add("suite_aborted", error=repr(error))
        save(root / "summary.json", {"passed": False, "results": results, "error": repr(error),
                                     "evidence_policy": "All owned files retained; no product changes"})
        raise
    finally:
        evidence.close()


def main():
    """不带execute仅打印计划；Print a plan unless execution is explicitly requested."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--binary")
    parser.add_argument("--binary-sha256")
    parser.add_argument("--revision")
    parser.add_argument("--output", default="/var/tmp/ling-acceptance-storage-" + uuid.uuid4().hex)
    parser.add_argument("--enospc-worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--parent-namespace", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.enospc_worker:
        return enospc_worker(args)
    if not args.execute:
        print(json.dumps({"plan": PLAN, "proposed_output": args.output, "execution": "not started"}, indent=2))
        return 0
    require(args.binary and args.binary_sha256 and args.revision, "--binary, --binary-sha256 and --revision are required")
    return execute(args)


if __name__ == "__main__":
    raise SystemExit(main())
