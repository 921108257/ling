"""纯离线驱动契约：不启动服务、不使用WSL；Offline driver contracts without servers or WSL."""
import contextlib
import io
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import MagicMock, patch
import zlib

import storage_acceptance as acceptance


def record(payload):
    """独立磁盘字节夹具；Independent on-disk record fixture."""
    return struct.pack(">II", len(payload), zlib.crc32(payload)) + payload + b"LGCMT001"


def journal_bytes(version=1):
    """固定40字节事件尾字段，避免复用被测解析器；Pin the 40-byte event tail independently."""
    head = b"LGJRNL01" + struct.pack(">I", version) + bytes(range(16)) + struct.pack(">II", 2, 2)
    header = head + struct.pack(">I", zlib.crc32(head))
    payload = (b"\x01\0\0\0\x01" + struct.pack(">HIQBI", 0, 1, 1, 1, 1) + b"k" +
               bytes(range(16, 32)) + struct.pack(">QQQ", 2**64 - 1, 7, 1760000000123))
    return header + record(payload)


class MemoryStream:
    """逐字节拆帧，不连接网络；Fragment one byte at a time without any socket."""
    def __init__(self, data):
        self.data = data

    def settimeout(self, value):
        pass

    def recv(self, size):
        chunk, self.data = self.data[:1], self.data[1:]
        return chunk


class StorageAcceptanceTests(unittest.TestCase):
    """工具边界与独立格式证据；Driver boundaries and independent format evidence."""
    def test_strict_value_golden_bytes_keep_unsigned_precision_and_binary_type(self):
        vectors = [(None, b"\0"), (False, b"\1\0"), (True, b"\1\1"),
                   (2**64 - 1, b"\3" + b"\xff" * 8),
                   (b"\xff\0", b"\6\0\0\0\2\xff\0"),
                   ("中", b"\5\0\0\0\3\xe4\xb8\xad")]
        for value, wire in vectors:
            with self.subTest(value=value):
                self.assertEqual(acceptance.encode(value), wire)
                self.assertEqual(acceptance.decode(wire), (value, len(wire)))
        self.assertNotEqual(acceptance.encode("x"), acceptance.encode(b"x"))
        with self.assertRaises((OverflowError, struct.error)):
            acceptance.encode(-1)

    def test_decoder_rejects_bad_bool_count_depth_and_duplicate_map_keys(self):
        bad = [b"\1\2", b"\7\xff\xff\xff\xff", b"\6\0\0\0\2x",
               b"\10\0\0\0\2\5\0\0\0\1a\0\5\0\0\0\1a\0",
               b"\7\0\0\0\1" * 18 + b"\0"]
        for wire in bad:
            with self.subTest(wire=wire):
                with self.assertRaises(RuntimeError):
                    acceptance.decode(wire)

    def test_fragmented_frames_keep_request_identity_and_exact_errors(self):
        success = b"\0\3" + b"\xff" * 8
        client = acceptance.Client.__new__(acceptance.Client)
        client.stream = MemoryStream(struct.pack(">2sBBHQI", b"LG", 1, 2, 0, 29, len(success)) + success)
        self.assertEqual(client.frame(acceptance.time.monotonic() + 2), (2, 29, 2**64 - 1))
        code, detail = b"ERR_JOURNAL_UNAVAILABLE", b"byte offset 40"
        payload = (b"\5" + struct.pack(">I", len(code)) + code +
                   b"\5" + struct.pack(">I", len(detail)) + detail)
        client.stream = MemoryStream(struct.pack(">2sBBHQI", b"LG", 1, 6, 0, 0, len(payload)) + payload)
        with self.assertRaisesRegex(acceptance.WireError, "^ERR_JOURNAL_UNAVAILABLE: byte offset 40$"):
            client.frame(acceptance.time.monotonic() + 2)

    def test_complete_journal_fixture_has_real_tail_field_widths(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "journal.lgj"
            path.write_bytes(journal_bytes() + record(b"\2opaque-group") + record(b"\3opaque-checkpoint"))
            scan = acceptance.journal_scan(path)
        self.assertEqual(scan["status"], "complete")
        self.assertEqual([item["tag"] for item in scan["records"]], [1, 2, 3])
        self.assertEqual(scan["stream_id"], bytes(range(16)).hex())
        self.assertEqual(scan["events"], [{"db": 0, "shard": 1, "sequence": 1, "kind": 1, "key": "k",
            "epoch": bytes(range(16, 32)).hex(), "generation": 2**64 - 1, "revision": 7, "timestamp_ms": 1760000000123}])

    def test_journal_scanner_distinguishes_incomplete_and_corrupt_bytes(self):
        full = journal_bytes()
        crc_bad = bytearray(full)
        crc_bad[48] ^= 1
        cases = [(full + b"\0\0", "short_header", len(full)),
                 (full[:-4], "short_trailer", 40), (full[:49], "ambiguous_payload", 40),
                 (bytes(crc_bad) + b"\0\0", "bad_crc", 40),
                 (full[:-8] + b"BADTAIL!", "bad_trailer", 40)]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "journal.lgj"
            for content, status, offset in cases:
                with self.subTest(status=status):
                    path.write_bytes(content)
                    scan = acceptance.journal_scan(path)
                    self.assertEqual((scan["status"], scan["offset"]), (status, offset))
                    self.assertEqual(path.read_bytes(), content)

    def test_journal_header_version_is_checked_and_size_is_bounded_before_read(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "journal.lgj"
            path.write_bytes(journal_bytes(version=2))
            with self.assertRaisesRegex(RuntimeError, "invalid Journal header"):
                acceptance.journal_scan(path)
        with patch.object(Path, "stat", return_value=types.SimpleNamespace(st_size=128 * 1024 * 1024 + 1)), \
                patch.object(Path, "read_bytes") as read:
            with self.assertRaisesRegex(RuntimeError, "inspection budget"):
                acceptance.journal_scan(Path("never-read"))
            read.assert_not_called()

    def test_mutations_preserve_complete_prefix_and_report_first_fault_offset(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "journal.lgj"
            for mode, status, offset in (("short-header", "short_header", len(journal_bytes())),
                                         ("short-trailer", "short_trailer", len(journal_bytes())),
                                         ("ambiguous-payload", "ambiguous_payload", 40),
                                         ("middle-crc", "bad_crc", 40)):
                with self.subTest(mode=mode):
                    path.write_bytes(journal_bytes())
                    first, size, digest = acceptance.mutate(path, mode)
                    scan = acceptance.journal_scan(path)
                    self.assertEqual((first, scan["status"], scan["offset"]), (offset, status, offset))
                    self.assertEqual(size, path.stat().st_size)
                    self.assertEqual(digest, acceptance.sha(path))
                    if mode.startswith("short-"):
                        self.assertEqual(path.read_bytes()[:len(journal_bytes())], journal_bytes())

    def test_independent_failures_are_recorded_and_later_cases_still_run(self):
        evidence, visited = MagicMock(), []

        def operation(mode):
            visited.append(mode)
            if mode == "bad":
                raise RuntimeError("fixture failure, no product repair")

        with self.assertRaisesRegex(RuntimeError, "fixture failure"):
            acceptance.independent_subcases(evidence, "fixture", ("bad", "good"), operation)
        self.assertEqual(visited, ["bad", "good"])
        self.assertEqual([call.kwargs["passed"] for call in evidence.add.call_args_list], [False, True])
        operation = MagicMock(side_effect=KeyboardInterrupt())
        with self.assertRaises(KeyboardInterrupt):
            acceptance.independent_subcases(evidence, "fixture", ("one", "two"), operation)
        operation.assert_called_once_with("one")

    def test_full_archive_checks_every_file_and_records_original_ownership(self):
        with tempfile.TemporaryDirectory() as directory:
            source, destination = Path(directory) / "source", Path(directory) / "copy"
            source.mkdir()
            (source / "journal.lgj").write_bytes(journal_bytes())
            (source / "LOCK").write_bytes(b"")
            (source / "nested").mkdir()
            (source / "nested/probe").write_bytes(b"exact bytes")
            manifest = acceptance.archive(source, destination)
            saved = json.loads(destination.with_suffix(".manifest.json").read_text())
            self.assertEqual(set(manifest), {"journal.lgj", "LOCK", str(Path("nested/probe"))})
            self.assertEqual(saved["files"], manifest)
            self.assertIn("not ownership", saved["ownership_policy"])
            self.assertEqual(manifest["journal.lgj"]["source_uid"], (source / "journal.lgj").stat().st_uid)
            self.assertEqual((destination / "nested/probe").read_bytes(), b"exact bytes")

    def test_archive_refuses_a_changed_source_instead_of_claiming_a_backup(self):
        with tempfile.TemporaryDirectory() as directory:
            source, destination = Path(directory) / "source", Path(directory) / "copy"
            source.mkdir()
            path = source / "journal.lgj"
            path.write_bytes(journal_bytes())
            copytree = acceptance.shutil.copytree

            def mutate_after_copy(start, end):
                copytree(start, end)
                path.write_bytes(path.read_bytes() + b"changed")

            with patch.object(acceptance.shutil, "copytree", side_effect=mutate_after_copy):
                with self.assertRaisesRegex(RuntimeError, "bytes changed"):
                    acceptance.archive(source, destination)
            self.assertFalse(destination.with_suffix(".manifest.json").exists())

    def test_listener_requires_both_child_inode_and_exact_loopback_port(self):
        table = "header\n0: 0100007F:3039 00000000:0000 0A 0:0 00:0 0 0 0 77 0\n"
        with patch.object(Path, "iterdir", return_value=[Path("fd42")]), \
                patch.object(Path, "read_text", return_value=table), \
                patch.object(acceptance.os, "readlink", return_value="socket:[77]"):
            self.assertTrue(acceptance.listener_owned(123, 12345))
            self.assertFalse(acceptance.listener_owned(123, 12346))
        with patch.object(Path, "iterdir", return_value=[Path("fd42")]), \
                patch.object(Path, "read_text", return_value=table), \
                patch.object(acceptance.os, "readlink", return_value="socket:[88]"):
            self.assertFalse(acceptance.listener_owned(123, 12345))

    def test_request_failure_classification_never_replays_unknown_writes(self):
        evidence, client = MagicMock(), MagicMock()
        for error, unknown in ((acceptance.WireError("ERR_JOURNAL_FULL: quota"), False),
                               (acceptance.WireError("ERR_COMMIT_UNKNOWN: sync"), True),
                               (acceptance.WireError("LOCAL_EOF: truncated"), True), (TimeoutError("deadline"), True)):
            with self.subTest(error=error):
                client.request.reset_mock()
                client.request.side_effect = error
                result = acceptance.call(evidence, client, "SET", ["k", 1])
                self.assertEqual(result["write_result_may_be_unknown"], unknown)
                client.request.assert_called_once_with("SET", ["k", 1], 1)

    def test_runtime_injection_waits_for_idle_then_resubscribes_without_ping(self):
        audit, clock = [], [0.0]
        original_mutate = acceptance.mutate
        event = {"event_id": {"stream_id": bytes(range(16)), "db": 0, "shard": 1, "sequence": 1}}

        @contextlib.contextmanager
        def offline_server(binary, case, evidence, **options):
            case = Path(case)
            (case / "journal").mkdir(parents=True)
            path = case / "journal/journal.lgj"
            path.write_bytes(journal_bytes())
            writer, active, idle, server = MagicMock(), MagicMock(), MagicMock(), MagicMock()
            offset = len(journal_bytes()) if case.name == "short-header" else 40

            def request(role, command, arguments=(), kind=1):
                audit.append((case.name, role, command))
                if command == "INFO":
                    return {"events": {"subscription_polls": 1, "pending": int(case.name == "middle-crc")}}
                if command == "SET" and arguments[0] == "after-read-fault":
                    raise acceptance.WireError("ERR_JOURNAL_UNAVAILABLE: faulted")
                return True

            for role, client in (("writer", writer), ("active", active), ("idle", idle)):
                client.request.side_effect = lambda command, arguments=(), kind=1, role=role: request(role, command, arguments, kind)
            active.event.side_effect = [event, acceptance.WireError(f"ERR_JOURNAL_UNAVAILABLE: byte offset {offset}")]
            idle.event.side_effect = [event, acceptance.WireError("ERR_JOURNAL_UNAVAILABLE: faulted")]
            server.ready.return_value, server.client.side_effect = writer, [active, idle]
            yield server

        def inject(path, mode):
            audit.append((mode, "filesystem", "inject"))
            return original_mutate(path, mode)

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(acceptance, "running", side_effect=offline_server), \
                patch.object(acceptance, "mutate", side_effect=inject), \
                patch.object(acceptance.time, "monotonic", side_effect=lambda: clock[0]), \
                patch.object(acceptance.time, "sleep", side_effect=lambda seconds: clock.__setitem__(0, clock[0] + seconds)), \
                patch.object(acceptance.subprocess, "Popen") as start:
            evidence = MagicMock()
            acceptance.runtime_cases(Path("never-executed"), Path(directory), evidence)
            start.assert_not_called()
        for mode in ("short-header", "middle-crc"):
            actions = [(role, command) for case, role, command in audit if case == mode]
            first, injected = actions.index(("active", "UNSUBSCRIBE")), actions.index(("filesystem", "inject"))
            resubscribed = actions.index(("active", "SUBSCRIBE"), first)
            self.assertLess(first, injected)
            self.assertLess(injected, resubscribed)
            self.assertGreaterEqual(actions[first:injected].count(("writer", "INFO")), 10)
            self.assertNotIn(("active", "PING"), actions)
        quiet = [call.kwargs["quiet_seconds"] for call in evidence.add.call_args_list
                 if call.args[0] == "idle_subscription_quiescent"]
        self.assertTrue(all(seconds >= .25 for seconds in quiet))

    def test_stop_is_idempotent_and_uses_only_the_owned_child(self):
        child, evidence = MagicMock(), MagicMock()
        child.pid, child.poll.return_value, child.returncode = 456, None, None

        def killed():
            child.poll.return_value, child.returncode = -9, -9

        child.kill.side_effect = killed
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(acceptance.subprocess, "Popen", return_value=child) as start, \
                patch.object(acceptance.socket, "socket") as socket_factory:
            socket_factory.return_value.__enter__.return_value.getsockname.return_value = ("127.0.0.1", 12345)
            server = acceptance.Server(Path("owned-binary"), Path(directory), evidence)
            server.stop()
            server.stop()
            child.kill.assert_called_once_with()
            child.wait.assert_called_once_with(timeout=5)
            start.assert_called_once()
            self.assertTrue(server.log.closed)

    def test_constructor_logging_failure_reaps_its_child(self):
        child, evidence = MagicMock(), MagicMock()
        child.pid, child.poll.return_value = 456, None
        evidence.add.side_effect = OSError("evidence write failed")
        child.kill.side_effect = lambda: setattr(child.poll, "return_value", -9)
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(acceptance.subprocess, "Popen", return_value=child) as start, \
                patch.object(acceptance.socket, "socket") as socket_factory:
            socket_factory.return_value.__enter__.return_value.getsockname.return_value = ("127.0.0.1", 12345)
            with self.assertRaisesRegex(OSError, "evidence write failed"):
                acceptance.Server(Path("owned-binary"), Path(directory), evidence)
            child.kill.assert_called_once_with()
            child.wait.assert_called_once_with(timeout=5)
            self.assertTrue(start.call_args.kwargs["stdout"].closed)

    def test_enospc_failure_archive_still_unmounts_preserves_image_and_flushes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "inputs").mkdir()
            binary = root / "inputs/ling"
            binary.write_bytes(b"fixture, never executed")
            (root / ".storage-acceptance").write_text(acceptance.RUN_MARKER)
            (root / "environment.json").write_text(json.dumps({"binary_sha256": acceptance.sha(binary)}))
            args = types.SimpleNamespace(output=str(root), binary=str(binary), parent_namespace="parent")
            marker, evidence_instances = MagicMock(), []
            marker.read_text.return_value = "ling-acceptance\n"
            original_evidence, original_require = acceptance.Evidence, acceptance.require

            def evidence_factory(path):
                instance = original_evidence(path)
                evidence_instances.append(instance)
                return instance

            def tools_stub(command, evidence, **options):
                if command[0] == "mount":
                    (Path(command[-1]) / "journal").mkdir()
                return types.SimpleNamespace(stdout="mock private filesystem")

            def require_test_location(condition, message):
                # 仅把临时夹具位置替代WSL路径；Only substitute the offline fixture root for /var/tmp.
                if message != "unexpected worker root":
                    original_require(condition, message)

            unavailable = MagicMock()
            unavailable.__enter__.side_effect = RuntimeError("simulated server setup failure")
            with patch.object(acceptance, "MARKER", marker), \
                    patch.object(acceptance.sys, "platform", "linux"), \
                    patch.object(acceptance.os, "geteuid", return_value=0, create=True), \
                    patch.object(acceptance.os, "readlink", return_value="private"), \
                    patch.dict(acceptance.os.environ, {"WSL_DISTRO_NAME": "ling-acceptance"}), \
                    patch.object(acceptance.os, "posix_fallocate", create=True), \
                    patch.object(acceptance, "require", side_effect=require_test_location), \
                    patch.object(acceptance, "Evidence", side_effect=evidence_factory), \
                    patch.object(acceptance, "probe", side_effect=tools_stub), \
                    patch.object(acceptance, "running", return_value=unavailable), \
                    patch.object(acceptance, "archive", side_effect=OSError("simulated archive failure")), \
                    patch.object(acceptance.subprocess, "Popen") as start, \
                    patch.object(acceptance.subprocess, "run", return_value=types.SimpleNamespace(returncode=0, stderr="")) as run:
                with self.assertRaisesRegex(RuntimeError, "simulated server setup failure"):
                    acceptance.enospc_worker(args)
                start.assert_not_called()
                run.assert_called_once_with(["umount", str(root / "enospc/mount")],
                                            capture_output=True, text=True, timeout=10)
            self.assertTrue(evidence_instances[0].output.closed)
            entries = [json.loads(line) for line in (root / "actions.jsonl").read_text().splitlines()]
            self.assertEqual([entry["action"] for entry in entries],
                             ["private_mount", "unmount", "image_preserved", "cleanup_failed"])
            self.assertEqual(entries[-1]["errors"][0]["phase"], "failure_archive")

    def test_enospc_reports_ack_close_separately_and_requires_an_explicit_fault_first(self):
        event = {"event_id": {"stream_id": bytes(range(16)), "db": 0, "shard": 1, "sequence": 1}}
        for ack_error, fault in ((acceptance.WireError("LOCAL_EOF: incomplete frame"), "ERR_JOURNAL_UNAVAILABLE: faulted"),
                                  (BrokenPipeError(32, "Broken pipe"), "ERR_JOURNAL_UNAVAILABLE: faulted"),
                                  (acceptance.WireError("LOCAL_EOF: incomplete frame"), "LOCAL_EOF: incomplete frame")):
            with self.subTest(ack_error=ack_error, fault=fault), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                (root / "inputs").mkdir()
                binary = root / "inputs/ling"
                binary.write_bytes(b"fixture, never executed")
                (root / ".storage-acceptance").write_text(acceptance.RUN_MARKER)
                (root / "environment.json").write_text(json.dumps({"binary_sha256": acceptance.sha(binary)}))
                args = types.SimpleNamespace(output=str(root), binary=str(binary), parent_namespace="parent")
                marker = MagicMock()
                marker.read_text.return_value = "ling-acceptance\n"
                original_require, writes = acceptance.require, [0]
                writer, sub, server, rejected = MagicMock(), MagicMock(), MagicMock(), MagicMock()
                sub.event.side_effect = [event, acceptance.WireError(fault)]

                def subscribe_request(command, *arguments):
                    if command == "ACK":
                        raise ack_error
                    return True

                sub.request.side_effect = subscribe_request
                server.ready.return_value, server.client.return_value = writer, sub
                rejected.ready.side_effect = RuntimeError("fixture recovery rejected")

                def write_request(command, arguments=(), kind=1):
                    if command == "SET":
                        if arguments[0] == "after-disk-fault":
                            raise acceptance.WireError("ERR_JOURNAL_UNAVAILABLE: faulted")
                        writes[0] += 1
                        if writes[0] == 2:
                            raise acceptance.WireError("ERR_COMMIT_UNKNOWN: disk full")
                        return True
                    return 1 if command == "GET" else {"events": {}}

                writer.request.side_effect = write_request

                @contextlib.contextmanager
                def offline_server(binary, path, evidence, **options):
                    yield rejected if Path(path).name == "recovery" else server

                @contextlib.contextmanager
                def offline_trace(server, path, evidence):
                    trace = Path(path) / "mock.strace"
                    trace.write_text("write(...) = -1 ENOSPC (No space left on device)\n")
                    yield trace

                def tools_stub(command, evidence, **options):
                    if command[0] == "mount":
                        journal = Path(command[-1]) / "journal"
                        journal.mkdir()
                        (journal / "journal.lgj").write_bytes(journal_bytes())
                    return types.SimpleNamespace(stdout="mock private filesystem")

                def require_test_location(condition, message):
                    if message != "unexpected worker root":
                        original_require(condition, message)

                with patch.object(acceptance, "MARKER", marker), \
                        patch.object(acceptance.sys, "platform", "linux"), \
                        patch.object(acceptance.os, "geteuid", return_value=0, create=True), \
                        patch.object(acceptance.os, "readlink", return_value="private"), \
                        patch.dict(acceptance.os.environ, {"WSL_DISTRO_NAME": "ling-acceptance"}), \
                        patch.object(acceptance.os, "posix_fallocate", create=True), \
                        patch.object(acceptance.os, "statvfs", create=True,
                                     return_value=types.SimpleNamespace(f_bavail=0, f_frsize=4096)), \
                        patch.object(acceptance, "require", side_effect=require_test_location), \
                        patch.object(acceptance, "probe", side_effect=tools_stub), \
                        patch.object(acceptance, "running", side_effect=offline_server), \
                        patch.object(acceptance, "failed_io_trace", side_effect=offline_trace), \
                        patch.object(acceptance.subprocess, "Popen") as start, \
                        patch.object(acceptance.subprocess, "run", return_value=types.SimpleNamespace(returncode=0, stderr="")):
                    if fault.startswith("ERR_"):
                        self.assertEqual(acceptance.enospc_worker(args), 0)
                        outcome = json.loads((root / "enospc/outcomes.json").read_text())
                        self.assertFalse(outcome["stable_ack_error_response_observed"])
                        self.assertFalse(outcome["ack_result"]["ok"])
                        self.assertEqual(outcome["ack_result"]["error_type"], type(ack_error).__name__)
                    else:
                        with self.assertRaisesRegex(RuntimeError, "without an explicit Journal fault"):
                            acceptance.enospc_worker(args)
                        self.assertFalse((root / "enospc/outcomes.json").exists())
                    start.assert_not_called()

    def test_default_plan_starts_nothing_and_execute_refuses_windows(self):
        with patch.object(sys, "argv", ["storage_acceptance.py"]), \
                patch.object(acceptance.subprocess, "Popen") as start, \
                patch.object(acceptance.subprocess, "run") as run, contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(acceptance.main(), 0)
            self.assertEqual(json.loads(output.getvalue())["execution"], "not started")
            start.assert_not_called()
            run.assert_not_called()
        with patch.object(acceptance.sys, "platform", "win32"), \
                patch.object(acceptance.subprocess, "Popen") as start:
            with self.assertRaisesRegex(RuntimeError, "dedicated WSL as root"):
                acceptance.execute(types.SimpleNamespace())
            start.assert_not_called()


if __name__ == "__main__":
    unittest.main()
