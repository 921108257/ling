"""冻结本轮现有证据的逐文件清单；Freeze the current run's evidence file inventory."""
import hashlib
import json
from pathlib import Path
import stat

root = Path('/var/tmp/ling-acceptance-storage-05428e9d26fa4bf084d8eac72e2fa42f')
destination = root / 'evidence-files.manifest.json'
if destination.exists():
    raise RuntimeError('manifest already exists; no overwrite')
files = {}
for path in sorted(root.rglob('*')):
    status = path.lstat()
    if stat.S_ISDIR(status.st_mode):
        continue
    if not stat.S_ISREG(status.st_mode):
        raise RuntimeError(f'nonregular evidence entry: {path}')
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    files[str(path.relative_to(root))] = {
        'bytes': status.st_size, 'sha256': digest.hexdigest(),
        'uid': status.st_uid, 'gid': status.st_gid, 'mode': stat.S_IMODE(status.st_mode),
    }
payload = {'scope': 'All regular evidence files, excluding this self-describing manifest', 'files': files}
with destination.open('x', encoding='utf-8') as output:
    json.dump(payload, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps({'files': len(files), 'bytes': sum(x['bytes'] for x in files.values()),
                  'manifest_sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
