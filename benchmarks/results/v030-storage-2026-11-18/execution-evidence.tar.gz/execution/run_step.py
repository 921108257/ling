"""保存每步原始输出和退出码；Preserve each owned command's raw output and exit status."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("step")
parser.add_argument("command", nargs=argparse.REMAINDER)
args = parser.parse_args()
root = Path(__file__).resolve().parent
if not args.step.replace("-", "").isalnum() or not args.command:
    parser.error("simple unique step name and command required")
start = time.monotonic_ns()
with (root / (args.step + ".stdout.bin")).open("xb") as output, \
     (root / (args.step + ".stderr.bin")).open("xb") as errors:
    process = subprocess.Popen(args.command, stdout=output, stderr=errors)
    status = process.wait()
metadata = {"command": args.command, "exit_code": status, "duration_seconds": (time.monotonic_ns() - start) / 1e9,
            "completed_utc": datetime.now(timezone.utc).isoformat()}
(root / (args.step + ".json")).write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(metadata, ensure_ascii=False))
for label in ("stdout", "stderr"):
    data = (root / (args.step + "." + label + ".bin")).read_bytes()
    if data:
        print(label + ":")
        if b"\0" in data[:50]:
            boundary = data.rfind(b"\0") + 1
            print(data[:boundary].decode("utf-16le", errors="replace"))
            print(data[boundary:].decode("utf-8", errors="replace"))
        else:
            print(data.decode("utf-8", errors="replace"))
raise SystemExit(status)
