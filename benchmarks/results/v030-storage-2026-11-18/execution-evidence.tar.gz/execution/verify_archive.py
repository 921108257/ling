"""完整读取归档并核对所有证据；Read the full archive and verify every evidence file."""
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

run_id = '05428e9d26fa4bf084d8eac72e2fa42f'
archive = Path(__file__).resolve().parent.parent / f'storage-evidence-{run_id}.tar.gz'
prefix = f'ling-acceptance-storage-{run_id}/'
digests = {}
documents = {}
metadata = {}
with tarfile.open(archive, 'r:gz') as source:
    names = set()
    for item in source:
        if item.name in names:
            raise RuntimeError(f'duplicate member: {item.name}')
        names.add(item.name)
        if item.name.rstrip('/') == prefix.rstrip('/'):
            assert item.isdir()
            continue
        assert item.name.startswith(prefix), item.name
        relative = item.name[len(prefix):]
        assert '..' not in PurePosixPath(relative).parts and not relative.startswith('/')
        if item.isdir():
            continue
        assert item.isfile(), item.name
        digest = hashlib.sha256()
        count = 0
        buffer = bytearray() if relative.endswith('.json') else None
        with source.extractfile(item) as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(chunk)
                count += len(chunk)
                if buffer is not None:
                    assert len(buffer) + len(chunk) <= 2 * 1024 * 1024
                    buffer.extend(chunk)
        assert count == item.size
        digests[relative] = {'bytes': count, 'sha256': digest.hexdigest()}
        metadata[relative] = {'mode': item.mode, 'uid': item.uid, 'gid': item.gid}
        if buffer is not None:
            documents[relative] = json.loads(buffer)

# 到gzip EOF检查CRC与尾部，不能只读取tar成员列表。
# Read gzip through EOF to validate its CRC/trailer, beyond merely listing tar headers.
uncompressed_bytes = 0
with gzip.open(archive, 'rb') as stream:
    for chunk in iter(lambda: stream.read(1024 * 1024), b''):
        uncompressed_bytes += len(chunk)

manifest_name = 'evidence-files.manifest.json'
manifest = documents[manifest_name]['files']
assert set(digests) == set(manifest) | {manifest_name}
for relative, expected in manifest.items():
    assert digests[relative] == {key: expected[key] for key in ['bytes', 'sha256']}, relative
    assert metadata[relative] == {key: expected[key] for key in ['mode', 'uid', 'gid']}, relative

backup_files = 0
for relative, document in documents.items():
    if not relative.endswith('.manifest.json') or relative == manifest_name:
        continue
    backup_directory = relative.removesuffix('.manifest.json')
    for child, expected in document['files'].items():
        target = f'{backup_directory}/{child}'
        assert digests[target] == {key: expected[key] for key in ['bytes', 'sha256']}, target
        assert metadata[target] == {'mode': int(expected['copy_mode'], 8),
                                    'uid': expected['copy_uid'], 'gid': expected['copy_gid']}, target
        backup_files += 1

assert digests['inputs/ling']['sha256'] == '70b209554df2f236c6c4c30d6bbae5ec001a3b2754761038265483f659a0f285'
assert digests['inputs/storage_acceptance.py']['sha256'] == 'c120d9112ff7b71d592641f8f1a173286bf09c95dd2ac3ba2f708cf0edcef2c7'
assert digests['enospc/disk.ext4'] == {'bytes': 67108864,
    'sha256': '16dc34d7b5b7312040aff8558697a5419db77773a4dc08d40d9ca0c4e918dd7d'}
assert digests[manifest_name]['sha256'] == 'aa48af214f2f7b03dd1567333466187d9ed49bc22ad5817fcd383c2c6341c1d7'
assert 'summary.json' in documents and not documents['summary.json']['passed']
for case in ['ambiguous-payload', 'middle-crc']:
    assert digests[f'startup/{case}/injected-journal/journal.lgj'] == digests[f'startup/{case}/journal/journal.lgj']
archive_hash = hashlib.sha256()
with archive.open('rb') as source:
    for chunk in iter(lambda: source.read(1024 * 1024), b''):
        archive_hash.update(chunk)
result = {'archive': str(archive), 'archive_bytes': archive.stat().st_size,
          'archive_sha256': archive_hash.hexdigest(), 'regular_files_verified': len(digests),
          'backup_files_verified': backup_files, 'tar_uncompressed_bytes': uncompressed_bytes,
          'manifest_sha256': digests[manifest_name]['sha256'], 'verification_passed': True,
          'product_suite_passed': documents['summary.json']['passed']}
destination = archive.with_suffix(archive.suffix + '.verification.json')
with destination.open('x', encoding='utf-8') as output:
    json.dump(result, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
