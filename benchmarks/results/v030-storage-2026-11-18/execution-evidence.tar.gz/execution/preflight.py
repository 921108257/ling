"""仅查看专用环境，不启动服务；Inspect the dedicated environment without starting a server."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

binary = Path("/root/ling-acceptance/v020-public-441ffc7/ling/ling")
output = Path("/var/tmp/ling-acceptance-storage-05428e9d26fa4bf084d8eac72e2fa42f")
processes = []
for entry in Path("/proc").iterdir():
    if not entry.name.isdigit():
        continue
    try:
        command = (entry / "comm").read_text().strip()
        arguments = (entry / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
        if command in ("ling", "redis-server", "cargo-fuzz", "libfuzzer") or any(
            name in arguments for name in ("benchmarks/v030.py", "benchmarks/redis_compare.py", "benchmarks/open_load.py")):
            processes.append({"pid": int(entry.name), "comm": command, "args": arguments})
    except OSError:
        pass
marker = Path("/root/ling-acceptance/.wsl-crash-acceptance")
commands = {name: shutil.which(name) for name in ("setpriv", "unshare", "mkfs.ext4", "mount", "umount", "findmnt", "strace", "tar")}
with binary.open("rb") as source:
    digest = hashlib.file_digest(source, "sha256").hexdigest()
report = {"uid": os.getuid(), "distro": os.environ.get("WSL_DISTRO_NAME"), "processes": processes,
          "binary_sha256": digest, "output_exists": output.exists(), "commands": commands,
          "marker": marker.read_text(), "free_wsl": shutil.disk_usage("/var/tmp").free,
          "free_host": shutil.disk_usage("/mnt/c").free}
print(json.dumps(report, indent=2))
assert not processes, "unexpected service/test load"
assert report["uid"] == 0 and report["distro"] == "ling-acceptance" and report["marker"] == "ling-acceptance\n"
assert digest == "70b209554df2f236c6c4c30d6bbae5ec001a3b2754761038265483f659a0f285"
assert not output.exists()
assert all(commands.values()), "missing required tool"
assert report["free_wsl"] >= 10 * 1024**3 and report["free_host"] >= 10 * 1024**3
