"""有意中断真实自有驱动，验证 Linux 清理；Interrupt owned smoke drivers to verify Linux cleanup."""
import importlib.util
from pathlib import Path
import shutil
from types import SimpleNamespace

source = Path('/root/ling-acceptance/v030-source')
spec = importlib.util.spec_from_file_location('layout', source / 'benchmarks/run-v030-layout.py')
layout = importlib.util.module_from_spec(spec)
spec.loader.exec_module(layout)
args = SimpleNamespace(source=source,
    binary=Path('/root/ling-acceptance/v020-public-441ffc7/ling/ling'),
    output=Path('/root/ling-acceptance/layout-cleanup-smoke-20261118-0504'), seconds=600, rate=5)
if Path('/root/ling-acceptance/.wsl-crash-acceptance').read_text() != 'ling-acceptance\n':
    raise SystemExit('dedicated environment mismatch')
if layout.sha256(args.binary) != layout.BINARY_SHA256:
    raise SystemExit('binary mismatch')
args.output.mkdir(exist_ok=False)
shutil.copy2(__file__, args.output / Path(__file__).name)
entries = layout.plan(args)
hashes = layout.freeze(args, entries)
original_ready = layout.shadow_ready

def interrupt_after_progress(entry):
    """只模拟控制器中断，不改写服务或进度证据；Simulate controller interruption without altering workload evidence."""
    if original_ready(entry):
        raise RuntimeError('intentional cleanup smoke after worker progress')
    return False

layout.shadow_ready = interrupt_after_progress
code = layout.orchestrate(args, entries, hashes)
result = layout.read_json(args.output / 'layout-result.json')
passed = (code == 1 and result['orchestration_passed'] is False
          and any('intentional cleanup smoke' in error for error in result['errors'])
          and not result['remaining_processes'] and len(result['driver_exits']) == 2
          and all(row['exit_code'] == 130 for row in result['driver_exits'])
          and sum(row.get('action') == 'signal' and row.get('signal') == 2
                  for row in result['cleanup_events']) == 2)
layout.save(args.output / 'cleanup-smoke-result.json', {'passed': passed,
    'scope': 'intentional controller failure, two owned drivers; not performance/calibration/endurance',
    'orchestrator_exit': code})
raise SystemExit(0 if passed else 1)
