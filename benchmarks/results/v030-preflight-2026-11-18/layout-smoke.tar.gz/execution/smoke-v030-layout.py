"""验证真实 Linux 编排机制；Exercise real Linux orchestration, never count as endurance."""
import hashlib
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace

source = Path('/root/ling-acceptance/v030-source')
binary = Path('/root/ling-acceptance/v020-public-441ffc7/ling/ling')
output = Path('/root/ling-acceptance/layout-smoke-20261118-0454')
if Path('/root/ling-acceptance/.wsl-crash-acceptance').read_text() != 'ling-acceptance\n':
    raise SystemExit('dedicated environment marker mismatch')
spec = importlib.util.spec_from_file_location('layout', source / 'benchmarks/run-v030-layout.py')
layout = importlib.util.module_from_spec(spec)
spec.loader.exec_module(layout)
if layout.sha256(binary) != layout.BINARY_SHA256:
    raise SystemExit('release identity mismatch')
args = SimpleNamespace(source=source, binary=binary, output=output, seconds=600, rate=5)
output.mkdir(exist_ok=False)
entries = layout.plan(args)
for entry in entries:
    entry['seconds'] = 90 if entry['phase'] == 'shadow' else 10
    entry['command'][entry['command'].index('--seconds')+1] = str(entry['seconds'])
layout.save(output / 'smoke-profile.json', {
    'scope': 'Linux orchestration smoke only, neither calibration nor endurance',
    'shadow_seconds': 90, 'pressure_seconds_each': 10,
    'harness_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
hashes = layout.freeze(args, entries)
raise SystemExit(layout.orchestrate(args, entries, hashes))
