"""隔离真实制品的开放负载，保存自有服务的资源与退出记录。
Run open-arrival load against an owned release process and preserve resource evidence.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

OWNED_DRIVER = '''"""Guard every load connection against the parent's owned Linux listener."""
import sys
from pathlib import Path
source, pid, port = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
del sys.argv[1:4]
sys.path.insert(0, str(source / "benchmarks"))
import open_load
from redis_compare import owns_listener
original = open_load.BoundedClient.__init__
def owned(self, target, timeout, register):
    if target != port or not owns_listener(pid, port):
        raise RuntimeError("owned listener absent before connection")
    original(self, target, timeout, register)
    if not owns_listener(pid, port):
        self.close()
        raise RuntimeError("owned listener absent after HELLO")
open_load.BoundedClient.__init__ = owned
raise SystemExit(open_load.main())
'''


def save(path, value):
    """结果仅写本轮全新目录；Write results only inside this fresh run."""
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    """冻结制品后逐模式运行，绝不清理已有目录或其他进程。
    Freeze the release and run modes serially; never clean existing paths or other processes.
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=int, default=60)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    if sys.platform != "linux" or not 1 <= args.seconds <= 60 or not 1 <= args.repeats <= 3:
        parser.error("Linux required; seconds 1..60 and repeats 1..3")
    source, binary = args.source.resolve(strict=True), args.binary.resolve(strict=True)
    if hashlib.file_digest(binary.open("rb"), "sha256").hexdigest() != args.sha256:
        parser.error("release hash mismatch")
    sys.path.insert(0, str(source / "benchmarks"))
    from redis_compare import LingClient, configuration, free_port, owns_listener, resource_snapshot
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    frozen = output / "ling"
    shutil.copy2(binary, frozen)
    if hashlib.file_digest(frozen.open("rb"), "sha256").hexdigest() != args.sha256:
        raise RuntimeError("frozen release hash mismatch")
    shutil.copyfile(__file__, output / "run-open-acceptance.py")
    wrapper = output / "owned-open-load.py"
    wrapper.write_text(OWNED_DRIVER, encoding="utf-8")
    save(output / "plan.json", {"created_utc": datetime.now(timezone.utc).isoformat(),
        "release_revision": args.revision, "release_sha256": args.sha256,
        "release_version": subprocess.check_output([str(frozen), "--version"], text=True).strip(),
        "source_head": subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip(),
        "source_status": subprocess.check_output(["git", "-C", str(source), "status", "--short"], text=True),
        "stage": "pre-release", "phases_seconds_each": args.seconds, "repeats": args.repeats,
        "baseline_rate": 100, "overload_rate": 5000, "recovery_rate": 100,
        "connections": 32, "queue_capacity": 512, "server_request_timeout_ms": 50,
        "server_cpus": [0, 1], "client_cpus": [2, 3], "sample_sleep_seconds": 1,
        "sample_timing": "actual monotonic timestamps; INFO may add up to its 2-second deadline",
        "scope": "shared WSL host; Python client/logging/queue can limit arrivals; errors and drops remain distinct"})
    results = []
    for mode in ("fast", "reliable"):
        for repeat in range(args.repeats):
            directory = output / f"{mode}-{repeat}"
            directory.mkdir()
            port = free_port()
            config = directory / "ling.toml"
            config.write_text(configuration("ling", mode, port, 32, 268435456, 1073741824)
                              .replace("request_timeout_ms=30000", "request_timeout_ms=50"), encoding="utf-8")
            row = {"mode": mode, "repeat": repeat, "server_port": port, "passed": False,
                   "cleanup_errors": []}
            server = driver = observer = None
            def owned_observer():
                """任何新连接前后均验证自有监听；Guard both sides of a new observer connection."""
                if server.poll() is not None or not owns_listener(server.pid, port):
                    raise RuntimeError("owned listener absent before observer connection")
                candidate = LingClient(port, 2)
                if server.poll() is not None or not owns_listener(server.pid, port):
                    candidate.close()
                    raise RuntimeError("owned listener absent after observer HELLO")
                return candidate
            def cleanup(label, action):
                """清理错误不能跳过其余自有进程；Continue owned-process cleanup after errors."""
                try:
                    action()
                except Exception as error:
                    row["cleanup_errors"].append({"step": label, "error": repr(error)})
            with (directory / "server.log").open("wb") as log, \
                 (directory / "driver.log").open("wb") as driver_log, \
                 (directory / "resources.jsonl").open("w", encoding="utf-8") as resources:
                try:
                    server = subprocess.Popen(["taskset", "-c", "0,1", str(frozen), "--config", str(config)],
                                              cwd=directory, stdout=log, stderr=log)
                    until = time.monotonic() + 15
                    while not owns_listener(server.pid, port):
                        if server.poll() is not None or time.monotonic() >= until:
                            raise RuntimeError("owned server did not acquire listener")
                        time.sleep(.02)
                    observer = owned_observer()
                    command = ["taskset", "-c", "2,3", sys.executable, "-B", str(wrapper),
                        str(source), str(server.pid), str(port),
                        "--port", str(port), "--output", str(directory / "load"), "--connections", "32",
                        "--queue-capacity", "512", "--request-timeout", "2", "--binary", str(frozen),
                        "--config", str(config)]
                    for phase in ("baseline", "overload", "recovery"):
                        command += [f"--{phase}-seconds", str(args.seconds)]
                    row["driver_command"] = command
                    driver = subprocess.Popen(command, cwd=source, stdout=driver_log, stderr=driver_log)
                    until = time.monotonic() + 3 * args.seconds + 90
                    while driver.poll() is None:
                        if server.poll() is not None or not owns_listener(server.pid, port):
                            raise RuntimeError("owned listener disappeared during load")
                        if time.monotonic() >= until:
                            raise TimeoutError("load exceeded its overall deadline")
                        sample = {"monotonic_ns": time.monotonic_ns(), "server": resource_snapshot(server.pid),
                                  "driver": resource_snapshot(driver.pid)}
                        try:
                            if observer is None:
                                observer = owned_observer()
                            sample["info"] = observer.request("INFO", ["all"])
                        except Exception as error:
                            sample["info_error"] = repr(error)
                            if observer is not None:
                                cleanup("failed observer close", observer.close)
                            observer = None
                        resources.write(json.dumps(sample, default=lambda value: {"hex": value.hex()}) + "\n")
                        resources.flush()
                        time.sleep(1)
                    row["driver_exit"] = driver.returncode
                    row["load_summary"] = json.loads((directory / "load/summary.json").read_text())
                    row["passed"] = driver.returncode == 0 and row["load_summary"]["passed"]
                except BaseException as error:
                    row["failure"] = repr(error)
                finally:
                    if driver is not None and driver.poll() is None:
                        cleanup("driver terminate", driver.terminate)
                        try:
                            driver.wait(10)
                        except subprocess.TimeoutExpired:
                            cleanup("driver kill", driver.kill)
                            cleanup("driver reap", lambda: driver.wait(5))
                        except Exception as error:
                            row["cleanup_errors"].append({"step": "driver wait", "error": repr(error)})
                        if driver.poll() is None:
                            cleanup("driver fallback kill", driver.kill)
                            cleanup("driver fallback reap", lambda: driver.wait(5))
                    if server is not None and server.poll() is None and owns_listener(server.pid, port):
                        try:
                            if observer is None:
                                observer = owned_observer()
                            if owns_listener(server.pid, port):
                                row["shutdown_response"] = observer.request("SHUTDOWN", [])
                                server.wait(10)
                        except Exception as error:
                            row["shutdown_error"] = repr(error)
                    if observer is not None:
                        cleanup("observer close", observer.close)
                    if server is not None and server.poll() is None:
                        cleanup("server terminate", server.terminate)
                        try:
                            server.wait(10)
                        except subprocess.TimeoutExpired:
                            cleanup("server kill", server.kill)
                            cleanup("server reap", lambda: server.wait(5))
                        except Exception as error:
                            row["cleanup_errors"].append({"step": "server wait", "error": repr(error)})
                        if server.poll() is None:
                            cleanup("server fallback kill", server.kill)
                            cleanup("server fallback reap", lambda: server.wait(5))
                    row["server_exit"] = server.returncode if server else None
                    row["driver_exit"] = driver.returncode if driver else None
                    row["passed"] = (row["passed"] and row.get("shutdown_response") is True
                                     and row["server_exit"] == 0 and not row["cleanup_errors"])
            save(directory / "result.json", row)
            results.append(row)
            save(output / "summary.json", {"passed": len(results) == 2 * args.repeats
                 and all(item["passed"] for item in results), "results": results})
            if not row["passed"]:
                return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
