"""Guard every load connection against the parent's owned Linux listener."""
import sys
from pathlib import Path
source, pid, port = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
del sys.argv[1:4]
sys.path.insert(0, str(source / "benchmarks"))
import open_load
from redis_compare import owns_listener
original = open_load.BoundedClient.__init__
def owned(self, target, timeout, register):
    if target != port or not owns_listener(pid, port):
        raise RuntimeError("owned listener absent before connection")
    original(self, target, timeout, register)
    if not owns_listener(pid, port):
        self.close()
        raise RuntimeError("owned listener absent after HELLO")
open_load.BoundedClient.__init__ = owned
raise SystemExit(open_load.main())
